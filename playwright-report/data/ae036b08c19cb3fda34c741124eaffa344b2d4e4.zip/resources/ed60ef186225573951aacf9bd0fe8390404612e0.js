(self.webpackChunkjavascript_nodejs = self.webpackChunkjavascript_nodejs || []).push([ [ 616 ], {
3205: function(e, t, i) {
var n = {
"./ru.yml": 9321
};
function a(e) {
var t = o(e);
return i(t);
}
function o(e) {
if (!i.o(n, e)) {
var t = new Error("Cannot find module '" + e + "'");
throw t.code = "MODULE_NOT_FOUND", t;
}
return n[e];
}
a.keys = function() {
return Object.keys(n);
}, a.resolve = o, e.exports = a, a.id = 3205;
},
4766: function(e, t, i) {
var n = {
"./ru.yml": 3342
};
function a(e) {
var t = o(e);
return i(t);
}
function o(e) {
if (!i.o(n, e)) {
var t = new Error("Cannot find module '" + e + "'");
throw t.code = "MODULE_NOT_FOUND", t;
}
return n[e];
}
a.keys = function() {
return Object.keys(n);
}, a.resolve = o, e.exports = a, a.id = 4766;
},
6188: function(e, t, i) {
var n = {
"./ru.yml": 5660
};
function a(e) {
var t = o(e);
return i(t);
}
function o(e) {
if (!i.o(n, e)) {
var t = new Error("Cannot find module '" + e + "'");
throw t.code = "MODULE_NOT_FOUND", t;
}
return n[e];
}
a.keys = function() {
return Object.keys(n);
}, a.resolve = o, e.exports = a, a.id = 6188;
},
1276: function(e, t, i) {
let n = i(1495), a = i(3102), o = i(8944);
const l = i(9907), {Recaptcha: s} = i(5543), r = i(773), c = i(9907).lang;
let u = i(5582), f = i(1898), p = i(4500), m = i(8242), d = i(5345);
r.i18n.add("auth", i(4766)("./" + c + ".yml"));
class h {
constructor(e) {
this.options = e, e.successRedirect || (e.successRedirect = window.location.href), 
this.options.providers = l.providers;
}
render() {
this.elem = document.createElement("div"), this.elem.innerHTML = m(u, this.options), 
this.options.message && this.showFormMessage(this.options.message), this.options.email && (this.elem.querySelector('[name="email"]').value = this.options.email, 
this.elem.querySelector('[name="email"]').removeAttribute("autofocus"), this.elem.querySelector('[name="password"]').setAttribute("autofocus", "")), 
this.initEventHandlers();
}
getElem() {
return this.elem || this.render(), this.elem;
}
successRedirect() {
window.location.href == this.options.successRedirect ? window.location.reload() : window.location.href = this.options.successRedirect;
}
clearFormMessages() {
[].forEach.call(this.elem.querySelectorAll(".text-input_invalid"), (function(e) {
e.classList.remove("text-input_invalid");
})), [].forEach.call(this.elem.querySelectorAll(".text-input__err"), (function(e) {
e.remove();
})), this.elem.querySelector("[data-notification]").innerHTML = "";
}
request(e) {
let t = n(e);
return t.addEventListener("loadstart", function() {
let e = this.startRequestIndication();
t.addEventListener("loadend", e);
}.bind(this)), t;
}
startRequestIndication() {
this.elem.classList.add("modal-overlay_light");
let e, t = this.elem.querySelector('[type="submit"]');
return t && (e = new o({
elem: t,
size: "small",
class: "",
elemClass: "button_loading"
}), e.start()), () => {
this.elem.classList.remove("modal-overlay_light"), e && e.stop();
};
}
initEventHandlers() {
this.delegate('[data-switch="register-form"]', "click", (function(e) {
e.preventDefault(), this.elem.innerHTML = m(f, this.options), this.registerCaptcha = new s(this.elem.querySelector("form")), 
_(this.elem);
})), this.delegate('[data-switch="login-form"]', "click", (function(e) {
e.preventDefault(), this.elem.innerHTML = m(u, this.options), _(this.elem);
})), this.delegate('[data-switch="forgot-form"]', "click", (function(e) {
e.preventDefault();
let t = this.elem.querySelector('[type="email"]');
this.elem.innerHTML = m(p, this.options), this.elem.querySelector('[type="email"]').value = t.value, 
_(this.elem);
})), this.delegate('[data-form="login"]', "submit", (function(e) {
e.preventDefault(), this.submitLoginForm(e.target);
})), this.delegate('[data-form="register"]', "submit", (function(e) {
e.preventDefault(), this.submitRegisterForm(e.target);
})), this.delegate('[data-form="forgot"]', "submit", (function(e) {
e.preventDefault(), this.submitForgotForm(e.target);
})), this.delegate("[data-provider]", "click", (function(e) {
e.preventDefault(), this.openAuthPopup("/auth/login/" + e.delegateTarget.dataset.provider);
})), this.delegate("[data-action-verify-email]", "click", (function(e) {
e.preventDefault();
let t = new FormData, i = e.delegateTarget.dataset.actionVerifyEmail;
t.append("email", i);
let n = this.request({
method: "POST",
url: "/auth/reverify",
body: t
}), a = this;
n.addEventListener("success", (function(e) {
200 == this.status ? a.showFormMessage({
html: r("auth.auth_form.letter_resend", {
email: i
}),
type: "success"
}) : a.showFormMessage({
type: "error",
html: e.result
});
}));
})), this.delegate("[data-action-accept-agreements]", "change", (function(e) {
let t = e.delegateTarget.checked;
this.elem.querySelector('[type="submit"]').disabled = !t;
}));
}
async submitRegisterForm(e) {
this.clearFormMessages();
let t = !1;
if (e.elements.email.value || (t = !0, this.showInputError(e.elements.email, r("auth.auth_form.enter_email"))), 
e.elements.displayName.value || (t = !0, this.showInputError(e.elements.displayName, r("auth.auth_form.enter_displayname"))), 
e.elements.password.value || (t = !0, this.showInputError(e.elements.password, r("auth.auth_form.enter_password"))), 
t) return;
await this.registerCaptcha.validateForm(e);
let i = new FormData(e);
i.append("successRedirect", this.options.successRedirect);
let n = this.request({
method: "POST",
url: "/auth/register",
normalStatuses: [ 201, 400, 403 ],
body: i
}), a = this;
n.addEventListener("success", (function(t) {
if (201 == this.status) return a.elem.innerHTML = m(u, a.options), void a.showFormMessage({
html: r("auth.auth_form.letter_sent", {
email: e.elements.email.value,
notifyEmail: "notify@javascript.ru"
}),
type: "success"
});
if (400 != this.status) 403 != this.status ? a.showFormMessage({
html: r("auth.auth_form.unknown_error"),
type: "error"
}) : new d.Error(t.result.message); else for (let i in t.result.errors) a.showInputError(e.elements[i], t.result.errors[i]);
}));
}
submitForgotForm(e) {
this.clearFormMessages();
let t = !1;
if (e.elements.email.value || (t = !0, this.showInputError(e.elements.email, r("auth.auth_form.enter_email"))), 
t) return;
let i = new FormData(e);
i.append("successRedirect", this.options.successRedirect);
let n = this.request({
method: "POST",
url: "/auth/forgot",
normalStatuses: [ 200, 404, 403 ],
body: i
}), a = this;
n.addEventListener("success", (function(e) {
200 == this.status ? (a.elem.innerHTML = m(u, a.options), a.showFormMessage({
html: e.result,
type: "success"
})) : 404 == this.status ? a.showFormMessage({
html: e.result,
type: "error"
}) : 403 == this.status && a.showFormMessage({
html: e.result.message || r("auth.auth_form.forbidden"),
type: "error"
});
}));
}
showInputError(e, t) {
e.parentNode.classList.add("text-input_invalid");
let i = document.createElement("span");
i.className = "text-input__err", i.innerHTML = t, e.parentNode.appendChild(i);
}
showFormMessage(e) {
let t = e.html;
0 !== t.indexOf("<p>") && (t = "<p>" + t + "</p>");
let i = e.type;
if (-1 == [ "info", "error", "warning", "success" ].indexOf(i)) throw new Error("Unsupported type: " + i);
let n = document.createElement("div");
n.className = "login-form__" + i, n.innerHTML = t, this.elem.querySelector("[data-notification]").innerHTML = "", 
this.elem.querySelector("[data-notification]").appendChild(n);
}
submitLoginForm(e) {
this.clearFormMessages();
let t = !1;
if (e.elements.email.value || (t = !0, this.showInputError(e.elements.email, r("auth.auth_form.enter_email"))), 
e.elements.password.value || (t = !0, this.showInputError(e.elements.password, r("auth.auth_form.enter_password"))), 
t) return;
let i = n({
method: "POST",
url: "/auth/login/local",
noDocumentEvents: !0,
normalStatuses: [ 200, 401 ],
body: new FormData(e)
}), a = this.startRequestIndication();
i.addEventListener("success", (e => {
if (401 == i.status) return a(), void this.onAuthFailure(e.result.message);
this.options.callback ? (a(), this.onAuthSuccess(e.result.user)) : this.onAuthSuccess(e.result.user);
})), i.addEventListener("fail", (e => {
a(), this.onAuthFailure(e.reason);
}));
}
openAuthPopup(e) {
this.authPopup && !this.authPopup.closed && this.authPopup.close();
let t = (window.outerHeight - 600) / 2, i = (window.outerWidth - 800) / 2;
window.authForm = this, this.authPopup = window.open(e, "authForm", "width=800,height=600,scrollbars=0,top=" + t + ",left=" + i);
}
onAuthSuccess(e) {
window.currentUser = e, this.options.callback ? this.options.callback() : this.successRedirect();
}
onAuthFailure(e) {
this.showFormMessage({
html: e || r("auth.auth_form.auth_reject"),
type: "error"
});
}
}
function _(e) {
let t = e.querySelector("[autofocus]");
t && t.focus();
}
a.delegateMixin(h.prototype), e.exports = h;
},
641: function(e, t, i) {
let n = i(1276);
class a extends Modal {
constructor(e = {}) {
super(e), this.options.inModal = !0;
let t = new n(this.options);
this.setContent(t.getElem());
}
render() {
super.render(), this.elem.classList.add("login-form-modal");
}
}
e.exports = a;
},
8242: function(e, t, i) {
const n = i(9220).F, a = i(9907), o = i(773);
e.exports = function(e, t) {
return function(e) {
e.t = o, e.thumb = n, e.lang = a.lang, e.env = a.env;
}(t = t ? Object.create(t) : {}), e(t);
};
},
4629: function(e) {
e.exports = function() {
let e = document.cookie.match(/XSRF-TOKEN=([\w-]+)/);
return e ? e[1] : null;
};
},
9220: function(e, t) {
t.F = function(e, t, i) {
if (!e) return e;
let n = window.devicePixelRatio;
i *= n;
let a = (t *= n) <= 160 && i <= 160 ? "t" : t <= 320 && i <= 320 ? "m" : t <= 640 && i <= 640 ? "i" : t <= 1024 && i <= 1024 ? "h" : "";
return e.slice(0, e.lastIndexOf(".")) + a + e.slice(e.lastIndexOf("."));
};
},
1495: function(e, t, i) {
let n = i(5345), a = i(4629);
const o = i(9907).lang, l = i(773);
l.i18n.add("", i(3205)("./" + o + ".yml")), l.i18n.add("error.network", i(6188)("./" + o + ".yml")), 
document.addEventListener("xhrfail", (function(e) {
new n.Error(e.reason);
})), e.exports = function(e) {
let t = new XMLHttpRequest, i = e.method || "GET", n = e.body, o = e.url;
t.open(i, o, !e.sync), t.method = i;
let s = a();
s && !e.skipCsrf && t.setRequestHeader("X-XSRF-TOKEN", s), e.responseType && (t.responseType = e.responseType), 
"[object Object]" == {}.toString.call(n) && (t.setRequestHeader("Content-Type", "application/json;charset=UTF-8"), 
n = JSON.stringify(n)), e.noDocumentEvents || (t.addEventListener("loadstart", (e => {
t.timeStart = Date.now();
let i = c("xhrstart", e);
document.dispatchEvent(i);
})), t.addEventListener("loadend", (e => {
let t = c("xhrend", e);
document.dispatchEvent(t);
})), t.addEventListener("success", (e => {
let t = c("xhrsuccess", e);
t.result = e.result, document.dispatchEvent(t);
})), t.addEventListener("fail", (e => {
let t = c("xhrfail", e);
t.reason = e.reason, document.dispatchEvent(t);
}))), e.raw || t.setRequestHeader("Accept", "application/json"), t.setRequestHeader("X-Requested-With", "XMLHttpRequest");
let r = e.normalStatuses || [ 200 ];
function c(e, t) {
let i = new CustomEvent(e);
return i.originalEvent = t, i;
}
function u(e, i) {
let n = c("fail", i);
n.reason = e, t.dispatchEvent(n);
}
return t.addEventListener("error", (e => {
u(l("error.network.server_connection_error"), e);
})), t.addEventListener("timeout", (e => {
u(l("error.network.server_request_timeout"), e);
})), t.addEventListener("abort", (e => {
u(l("error.network.request_aborted"), e);
})), t.addEventListener("load", (i => {
if (!t.status) return void u(l("error.network.no_response"), i);
let n = e.responseType && "text" !== e.responseType ? t.response : t.responseText;
if ((t.getResponseHeader("Content-Type") || "").match(/^application\/json/) || e.json) try {
n = JSON.parse(n);
} catch (i) {
return void u(l("error.network.invalid_format"), i);
}
if (r.includes(t.status)) !function(e, i) {
let n = c("success", i);
n.result = e, t.dispatchEvent(n);
}(n, i); else {
u(n.info ? l("error.network.server_error_info", {
status: t.status,
info: n.info
}) : l("error.network.server_error", {
status: t.status
}), i);
}
})), setTimeout((function() {
t.send(n);
})), t;
};
},
773: function(e, t, i) {
"use strict";
const n = new (i(8679))("en");
let a = console.error;
function o(e) {
if (!n.hasPhrase(l, e)) {
!1 && a("No such phrase", e);
}
return n.t(l, ...arguments);
}
e.exports = o;
const l = i(9907).lang;
"en" !== l && n.setFallback(l, "en"), n.add = (...e) => (e = e.map((e => e.__esModule ? e.default : e)), 
n.addPhrase(l, ...e)), o.i18n = n;
},
4500: function(e, i, n) {
var a = n(7766);
e.exports = function(e) {
var i, n = "", o = {}, l = e || {};
return function(e, t, l, s, r, c, u, f, p, m, d, h, _) {
var b = function(i) {
var n;
if (null == i || "object" != typeof i) return i;
if (i instanceof t) return (n = new t).setTime(i.getTime()), n;
if (i instanceof e) {
n = [];
for (var a = 0, o = i.length; a < o; a++) n[a] = b(i[a]);
return n;
}
if (i instanceof s) {
for (var r in n = {}, i) i.hasOwnProperty(r) && (n[r] = b(i[r]));
return n;
}
throw new l("Unable to copy obj! Its type isn't supported.");
}, g = {
hr: {
type: "self_closing"
},
br: {
type: "self_closing"
},
wbr: {
type: "self_closing"
},
source: {
type: "self_closing"
},
img: {
type: "self_closing"
},
input: {
type: "self_closing"
},
a: {
type: "inline"
},
abbr: {
type: "inline"
},
acronym: {
type: "inline"
},
b: {
type: "inline"
},
code: {
type: "inline"
},
em: {
type: "inline"
},
font: {
type: "inline"
},
i: {
type: "inline"
},
ins: {
type: "inline"
},
kbd: {
type: "inline"
},
map: {
type: "inline"
},
pre: {
type: "inline"
},
samp: {
type: "inline"
},
small: {
type: "inline"
},
span: {
type: "inline"
},
strong: {
type: "inline"
},
sub: {
type: "inline"
},
sup: {
type: "inline"
},
textarea: {
type: "inline"
},
time: {
type: "inline"
},
label: {
content_type: "inline"
},
p: {
content_type: "inline"
},
h1: {
content_type: "inline"
},
h2: {
content_type: "inline"
},
h3: {
content_type: "inline"
},
h4: {
content_type: "inline"
},
h5: {
content_type: "inline"
},
h6: {
content_type: "inline"
},
ul: {
content_type: "list"
},
ol: {
content_type: "list"
},
select: {
content_type: "optionlist"
},
datalist: {
content_type: "optionlist"
}
}, v = [ "element", "modifier" ], y = {
prefix: "",
element: "__",
modifier: "_",
default_tag: "div",
nosrc_substitute: !0,
flat_elements: !0,
class_delimiter: ""
}, x = function() {
var e = b(y);
void 0 !== p && (e.prefix = p), void 0 !== u && (e.element = u), void 0 !== f && (e.modifier = f), 
void 0 !== c && (e.default_tag = c);
for (var t = 0; t < v.length; t++) {
var i = v[t];
void 0 === e["output_" + i] && (e["output_" + i] = e[i]);
}
return e;
};
o.bemto_custom_inline_tag = i = function(e, t) {
var o = this && this.block, l = this && this.attributes || {};
if (t = t || !1, n += (null == (i = "<") ? "" : i) + a.escape(null == (i = e) ? "" : i), 
l) for (var s in l) l.hasOwnProperty(s) && !1 !== l[s] && void 0 !== l[s] && (n += a.escape(null == (i = " ") ? "" : i) + a.escape(null == (i = s) ? "" : i) + (null == (i = '="') ? "" : i) + (null == (i = !0 === l[s] ? s : l[s]) ? "" : i) + (null == (i = '"') ? "" : i));
t ? n += null == (i = "/>") ? "" : i : (n += null == (i = ">") ? "" : i, o && o(), 
n += (null == (i = "</") ? "" : i) + a.escape(null == (i = e) ? "" : i) + (null == (i = ">") ? "" : i));
}, o.bemto_custom_tag = i = function(e, t) {
var i = this && this.block, l = this && this.attributes || {};
t = t || {};
var s, r, c = !1;
switch ("/" === (e = e || "div").substr(-1) && (c = !0, e = e.slice(0, -1)), t.type || (r = "block", 
g[s = e] && (r = g[s].type || r), r)) {
case "inline":
o.bemto_custom_inline_tag.call({
block: function() {
i && i();
},
attributes: l
}, e);
break;

case "self_closing":
o.bemto_custom_inline_tag.call({
attributes: l
}, e, !0);
break;

default:
c ? n = n + "<" + e + a.attrs(l, !0) + "/>" : (n = n + "<" + e + a.attrs(l, !0) + ">", 
i && i(), n = n + "</" + e + ">");
}
}, o.bemto_tag = i = function(e, t) {
var i = this && this.block, a = this && this.attributes || {}, l = x();
t = t || {};
var s = e || l.default_tag, r = k.length;
e || ("inline" === k[r - 1] ? s = "span" : "list" === k[r - 1] ? s = "li" : "optionlist" === k[r - 1] && (s = "option")), 
e && "span" != e && "div" != e || (a.href && (s = "a"), a.for && (s = "label"), 
a.type ? s = i ? "button" : "input" : a.src && (s = "img")), "list" === k[r - 1] && "li" !== s ? n += "<li>" : "list" !== k[r - 1] && "pseudo-list" !== k[r - 1] && "li" === s ? (n += "<ul>", 
k[k.length] = "pseudo-list") : "pseudo-list" === k[r - 1] && "li" !== s && (n += "</ul>", 
k = k.splice(0, k.length - 1));
var c, u, f = t.content_type || (u = "block", g[c = s] && (u = g[c].content_type || g[c].type || u), 
u);
k[k.length] = f, "img" == s && (a.alt && !a.title && (a.title = ""), a.title && !a.alt && (a.alt = a.title), 
a.alt || (a.alt = ""), "" === a.alt && (a.role = "presentation"), a.src || (!0 === l.nosrc_substitute ? a.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" : l.nosrc_substitute && (a.src = l.nosrc_substitute))), 
"input" == s && (a.type || (a.type = "text")), "main" == s && (a.role || (a.role = "main")), 
"html" == s && (n += "<!DOCTYPE html>"), o.bemto_custom_tag.call({
block: function() {
i && i && i();
},
attributes: a
}, s, t), "list" === k[r - 1] && "li" != s && (n += "</li>");
};
var w = [], k = [ "block" ];
o.b = i = function(t) {
var i = this && this.block, n = this && this.attributes || {}, a = x();
t && void 0 !== t.prefix && (a.prefix = t.prefix);
var l = t && t.tag || ("string" == typeof t ? t : ""), c = t && t.isElement, u = t && t.metadata, f = !1;
if (n.class) {
var p = n.class;
p instanceof e && (p = p.join(" ")), p = p.split(" ");
var m = [], d = !0, h = [];
if (function() {
var e = p;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t], o = {}, u = m[m.length - 1], _ = !1;
if (n.match(/^[A-Z-]+[A-Z0-9-]?$/)) l = n.toLowerCase(); else if (d && c && (o.context = w[w.length - 1]), 
(x = n.match(new r("^(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && u && u.name) u.modifiers || (u.modifiers = []), 
u.modifiers.push(x[1]); else {
(k = n.match(new r("^(?!" + a.modifier + "[A-Za-z0-9])" + a.element + "(.+)$"))) && (o.context = w[w.length - 1], 
n = k[1]), (A = n.match(new r("^(.*[A-Za-z0-9])(?!" + a.modifier + "$)" + a.element + "$"))) && (n = A[1], 
o.is_context = !0, _ = !0, f = !0, c = !1), (E = n.match(new r("^(.*?[A-Za-z0-9])(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && (n = E[1], 
o.modifiers || (o.modifiers = []), o.modifiers.push(E[2]));
var g = "", v = "()?";
if (a.prefix) {
"string" == typeof (O = a.prefix) && (O = {
"": O
});
var y = [];
O instanceof s && (function() {
var e = O;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
} else {
i = 0;
for (var t in e) {
i++;
n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
}
}
}.call(this), v = "(" + y.join("|") + ")?"), (Z = n.match(new r("^" + v + "([A-Za-z0-9]+.*)$"))) && (n = Z[2], 
g = Z[1] || "", void 0 !== (g = O[g]) && !0 !== g || (g = Z[1]));
}
o.prefix = (g || "").replace(/\-/g, "%DASH%").replace(/\_/g, "%UNDERSCORE%"), _ && n.match(/^[a-zA-Z0-9]+.*/) && h.push(o.context ? o.context + a.element + n : o.prefix + n), 
o.name = n, d = !1, o.context && o.context.length > 1 ? function() {
var e = o.context;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
(a = b(o)).context = [ n ], m.push(a);
} else {
i = 0;
for (var t in e) {
i++;
var a;
n = e[t];
(a = b(o)).context = [ n ], m.push(a);
}
}
}.call(this) : m.push(o);
}
} else {
i = 0;
for (var t in e) {
i++;
var x;
n = e[t], o = {}, u = m[m.length - 1], _ = !1;
if (n.match(/^[A-Z-]+[A-Z0-9-]?$/)) l = n.toLowerCase(); else if (d && c && (o.context = w[w.length - 1]), 
(x = n.match(new r("^(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && u && u.name) u.modifiers || (u.modifiers = []), 
u.modifiers.push(x[1]); else {
var k, A, E;
(k = n.match(new r("^(?!" + a.modifier + "[A-Za-z0-9])" + a.element + "(.+)$"))) && (o.context = w[w.length - 1], 
n = k[1]), (A = n.match(new r("^(.*[A-Za-z0-9])(?!" + a.modifier + "$)" + a.element + "$"))) && (n = A[1], 
o.is_context = !0, _ = !0, f = !0, c = !1), (E = n.match(new r("^(.*?[A-Za-z0-9])(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && (n = E[1], 
o.modifiers || (o.modifiers = []), o.modifiers.push(E[2]));
g = "", v = "()?";
if (a.prefix) {
var O;
"string" == typeof (O = a.prefix) && (O = {
"": O
});
var Z;
y = [];
O instanceof s && (function() {
var e = O;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
} else {
i = 0;
for (var t in e) {
i++;
n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
}
}
}.call(this), v = "(" + y.join("|") + ")?"), (Z = n.match(new r("^" + v + "([A-Za-z0-9]+.*)$"))) && (n = Z[2], 
g = Z[1] || "", void 0 !== (g = O[g]) && !0 !== g || (g = Z[1]));
}
o.prefix = (g || "").replace(/\-/g, "%DASH%").replace(/\_/g, "%UNDERSCORE%"), _ && n.match(/^[a-zA-Z0-9]+.*/) && h.push(o.context ? o.context + a.element + n : o.prefix + n), 
o.name = n, d = !1, o.context && o.context.length > 1 ? function() {
var e = o.context;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
(a = b(o)).context = [ n ], m.push(a);
} else {
i = 0;
for (var t in e) {
i++;
var a;
n = e[t];
(a = b(o)).context = [ n ], m.push(a);
}
}
}.call(this) : m.push(o);
}
}
}
}.call(this), !c && !h.length && m[0] && m[0].name && m[0].name.match(/^[a-zA-Z0-9]+.*/) && (m[0].is_context = !0, 
h.push(m[0].context ? m[0].context + a.element + m[0].name : m[0].prefix + m[0].name), 
f = !0), h.length && (a.flat_elements && function() {
var e = h;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
(n = e[t].match(new r("^(.*?[A-Za-z0-9])(?!" + a.modifier + "[A-Za-z0-9])" + a.element + ".+$"))) && (h[t] = n[1]);
} else {
i = 0;
for (var t in e) {
var n;
i++, (n = e[t].match(new r("^(.*?[A-Za-z0-9])(?!" + a.modifier + "[A-Za-z0-9])" + a.element + ".+$"))) && (h[t] = n[1]);
}
}
}.call(this), w[w.length] = h), m.length) {
var _ = [];
(function() {
var e = m;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
if ((o = e[t]).name) {
var n = o.prefix;
o.context && (n = o.context + a.output_element), _.push(n + o.name), o.modifiers && function() {
var e = o.modifiers;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var l = e[t];
_.push(n + o.name + a.output_modifier + l);
} else {
i = 0;
for (var t in e) {
i++;
l = e[t];
_.push(n + o.name + a.output_modifier + l);
}
}
}.call(this);
}
} else {
i = 0;
for (var t in e) {
var o;
if (i++, (o = e[t]).name) {
n = o.prefix;
o.context && (n = o.context + a.output_element), _.push(n + o.name), o.modifiers && function() {
var e = o.modifiers;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var l = e[t];
_.push(n + o.name + a.output_modifier + l);
} else {
i = 0;
for (var t in e) {
i++;
l = e[t];
_.push(n + o.name + a.output_modifier + l);
}
}
}.call(this);
}
}
}
}).call(this);
var g = a.class_delimiter;
g = g ? " " + g + " " : " ", n.class = _.join(g).replace(/%DASH%/g, "-").replace(/%UNDERSCORE%/g, "_");
} else n.class = void 0;
}
i ? o.bemto_tag.call({
block: function() {
i && i();
},
attributes: n
}, l, u) : o.bemto_tag.call({
attributes: n
}, l, u), !c && f && (w = w.splice(0, w.length - 1)), k = k.splice(0, k.length - 1);
}, o.e = i = function(e) {
var t = this && this.block, i = this && this.attributes || {};
(e = e && "string" == typeof e ? {
tag: e
} : e || {}).isElement = !0, o.b.call({
block: function() {
t && t();
},
attributes: i
}, e);
}, o.b.call({
block: function() {
o.e.call({
block: function() {
m ? o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.forgot_form.title")) ? "" : i);
},
attributes: {
class: "title"
}
}, "h4");
},
attributes: {
class: "line __header"
}
}) : h ? n += null == (i = h) ? "" : i : (n = n + "<p>" + (null == (i = _("auth.if_you_dont_have_account")) ? "" : i) + "&nbsp;", 
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.signup")) ? "" : i);
},
attributes: {
class: "button-link __register",
type: "button",
"data-switch": "register-form"
}
}, "button"), n += "</p>"), o.e.call({
block: function() {
o.e.call({
attributes: {
class: "line __notification",
"data-notification": a.escape(!0)
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.email_field_label") + ":") ? "" : i);
},
attributes: {
class: "label",
for: "forgot-email"
}
}, "label"), o.b.call({
block: function() {
o.e.call({
attributes: {
class: "control",
id: "forgot-email",
name: "email",
type: "email",
autofocus: a.escape(!0)
}
}, "input");
},
attributes: {
class: "text-input __input"
}
}, "span");
},
attributes: {
class: "line"
}
}), o.e.call({
block: function() {
o.e.call({
attributes: {
class: "recaptcha"
}
});
},
attributes: {
class: "line"
}
}), o.e.call({
block: function() {
o.b.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.forgot_form.do_recovery")) ? "" : i);
},
attributes: {
class: "text"
}
}, "span");
},
attributes: {
class: "button _action",
type: "submit"
}
}, "button"), m && o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.forgot_form.cancel")) ? "" : i);
},
attributes: {
class: "close-link tablet-only modal__close",
href: "#"
}
}, "a");
},
attributes: {
class: "line"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.forgot_form.login")) ? "" : i);
},
attributes: {
class: "button-link",
type: "button",
"data-switch": "login-form"
}
}, "button"), n += a.escape(null == (i = " ") ? "" : i), o.e.call({
block: function() {
n += "/";
},
attributes: {
class: "separator"
}
}, "span"), n += a.escape(null == (i = " ") ? "" : i), o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.forgot_form.registration")) ? "" : i);
},
attributes: {
class: "button-link",
"data-switch": "register-form"
}
}, "button");
},
attributes: {
class: "line __footer"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.login_form.login_using_socialnetworks")) ? "" : i);
},
attributes: {
class: "social-logins-title"
}
}, "h5"), n += a.escape(null == (i = " ") ? "" : i), function() {
var e = d;
if ("number" == typeof e.length) for (var t = 0, l = e.length; t < l; t++) {
let l = [ "social-login", "_" + (s = e[t]).id, "__social-login" ];
o.b.call({
block: function() {
n += a.escape(null == (i = s.name) ? "" : i);
},
attributes: {
class: a.classes([ l ], [ !0 ]),
"data-provider": a.escape(s.id)
}
}, "button"), n += a.escape(null == (i = " ") ? "" : i);
} else {
l = 0;
for (var t in e) {
var s;
l++;
let r = [ "social-login", "_" + (s = e[t]).id, "__social-login" ];
o.b.call({
block: function() {
n += a.escape(null == (i = s.name) ? "" : i);
},
attributes: {
class: a.classes([ r ], [ !0 ]),
"data-provider": a.escape(s.id)
}
}, "button"), n += a.escape(null == (i = " ") ? "" : i);
}
}
}.call(this);
},
attributes: {
class: "line __social-logins"
}
});
},
attributes: {
class: "body"
}
});
},
attributes: {
class: "form",
action: "#",
"data-form": "forgot"
}
}, "form");
},
attributes: {
class: a.classes([ [ "login-form", m ? "_modal" : "_inline" ] ], [ !0 ])
}
});
}.call(this, "Array" in l ? l.Array : "undefined" != typeof Array ? Array : void 0, "Date" in l ? l.Date : "undefined" != typeof Date ? Date : void 0, "Error" in l ? l.Error : "undefined" != typeof Error ? Error : void 0, "Object" in l ? l.Object : "undefined" != typeof Object ? Object : void 0, "RegExp" in l ? l.RegExp : "undefined" != typeof RegExp ? RegExp : void 0, "bemto_settings_default_tag" in l ? l.bemto_settings_default_tag : "undefined" != typeof bemto_settings_default_tag ? bemto_settings_default_tag : void 0, "bemto_settings_element" in l ? l.bemto_settings_element : "undefined" != typeof bemto_settings_element ? bemto_settings_element : void 0, "bemto_settings_modifier" in l ? l.bemto_settings_modifier : "undefined" != typeof bemto_settings_modifier ? bemto_settings_modifier : void 0, "bemto_settings_prefix" in l ? l.bemto_settings_prefix : "undefined" != typeof bemto_settings_prefix ? bemto_settings_prefix : void 0, "inModal" in l ? l.inModal : "undefined" != typeof inModal ? inModal : void 0, "providers" in l ? l.providers : [ {
name: "Github",
id: "github"
}, {
name: "Discord",
id: "discord"
}, {
name: "Facebook",
id: "facebook"
}, {
name: "Google",
id: "google"
}, {
name: "Яндекс",
id: "yandex"
}, {
name: "Вконтакте",
id: "vkontakte"
} ], "subtitle" in l ? l.subtitle : "undefined" != typeof subtitle ? subtitle : void 0, "t" in l ? l.t : "undefined" != typeof t ? t : void 0), 
n;
};
},
5582: function(e, i, n) {
var a = n(7766);
e.exports = function(e) {
var i, n = "", o = {}, l = e || {};
return function(e, t, l, s, r, c, u, f, p, m, d, h, _) {
var b = function(i) {
var n;
if (null == i || "object" != typeof i) return i;
if (i instanceof t) return (n = new t).setTime(i.getTime()), n;
if (i instanceof e) {
n = [];
for (var a = 0, o = i.length; a < o; a++) n[a] = b(i[a]);
return n;
}
if (i instanceof s) {
for (var r in n = {}, i) i.hasOwnProperty(r) && (n[r] = b(i[r]));
return n;
}
throw new l("Unable to copy obj! Its type isn't supported.");
}, g = {
hr: {
type: "self_closing"
},
br: {
type: "self_closing"
},
wbr: {
type: "self_closing"
},
source: {
type: "self_closing"
},
img: {
type: "self_closing"
},
input: {
type: "self_closing"
},
a: {
type: "inline"
},
abbr: {
type: "inline"
},
acronym: {
type: "inline"
},
b: {
type: "inline"
},
code: {
type: "inline"
},
em: {
type: "inline"
},
font: {
type: "inline"
},
i: {
type: "inline"
},
ins: {
type: "inline"
},
kbd: {
type: "inline"
},
map: {
type: "inline"
},
pre: {
type: "inline"
},
samp: {
type: "inline"
},
small: {
type: "inline"
},
span: {
type: "inline"
},
strong: {
type: "inline"
},
sub: {
type: "inline"
},
sup: {
type: "inline"
},
textarea: {
type: "inline"
},
time: {
type: "inline"
},
label: {
content_type: "inline"
},
p: {
content_type: "inline"
},
h1: {
content_type: "inline"
},
h2: {
content_type: "inline"
},
h3: {
content_type: "inline"
},
h4: {
content_type: "inline"
},
h5: {
content_type: "inline"
},
h6: {
content_type: "inline"
},
ul: {
content_type: "list"
},
ol: {
content_type: "list"
},
select: {
content_type: "optionlist"
},
datalist: {
content_type: "optionlist"
}
}, v = [ "element", "modifier" ], y = {
prefix: "",
element: "__",
modifier: "_",
default_tag: "div",
nosrc_substitute: !0,
flat_elements: !0,
class_delimiter: ""
}, x = function() {
var e = b(y);
void 0 !== p && (e.prefix = p), void 0 !== u && (e.element = u), void 0 !== f && (e.modifier = f), 
void 0 !== c && (e.default_tag = c);
for (var t = 0; t < v.length; t++) {
var i = v[t];
void 0 === e["output_" + i] && (e["output_" + i] = e[i]);
}
return e;
};
o.bemto_custom_inline_tag = i = function(e, t) {
var o = this && this.block, l = this && this.attributes || {};
if (t = t || !1, n += (null == (i = "<") ? "" : i) + a.escape(null == (i = e) ? "" : i), 
l) for (var s in l) l.hasOwnProperty(s) && !1 !== l[s] && void 0 !== l[s] && (n += a.escape(null == (i = " ") ? "" : i) + a.escape(null == (i = s) ? "" : i) + (null == (i = '="') ? "" : i) + (null == (i = !0 === l[s] ? s : l[s]) ? "" : i) + (null == (i = '"') ? "" : i));
t ? n += null == (i = "/>") ? "" : i : (n += null == (i = ">") ? "" : i, o && o(), 
n += (null == (i = "</") ? "" : i) + a.escape(null == (i = e) ? "" : i) + (null == (i = ">") ? "" : i));
}, o.bemto_custom_tag = i = function(e, t) {
var i = this && this.block, l = this && this.attributes || {};
t = t || {};
var s, r, c = !1;
switch ("/" === (e = e || "div").substr(-1) && (c = !0, e = e.slice(0, -1)), t.type || (r = "block", 
g[s = e] && (r = g[s].type || r), r)) {
case "inline":
o.bemto_custom_inline_tag.call({
block: function() {
i && i();
},
attributes: l
}, e);
break;

case "self_closing":
o.bemto_custom_inline_tag.call({
attributes: l
}, e, !0);
break;

default:
c ? n = n + "<" + e + a.attrs(l, !0) + "/>" : (n = n + "<" + e + a.attrs(l, !0) + ">", 
i && i(), n = n + "</" + e + ">");
}
}, o.bemto_tag = i = function(e, t) {
var i = this && this.block, a = this && this.attributes || {}, l = x();
t = t || {};
var s = e || l.default_tag, r = k.length;
e || ("inline" === k[r - 1] ? s = "span" : "list" === k[r - 1] ? s = "li" : "optionlist" === k[r - 1] && (s = "option")), 
e && "span" != e && "div" != e || (a.href && (s = "a"), a.for && (s = "label"), 
a.type ? s = i ? "button" : "input" : a.src && (s = "img")), "list" === k[r - 1] && "li" !== s ? n += "<li>" : "list" !== k[r - 1] && "pseudo-list" !== k[r - 1] && "li" === s ? (n += "<ul>", 
k[k.length] = "pseudo-list") : "pseudo-list" === k[r - 1] && "li" !== s && (n += "</ul>", 
k = k.splice(0, k.length - 1));
var c, u, f = t.content_type || (u = "block", g[c = s] && (u = g[c].content_type || g[c].type || u), 
u);
k[k.length] = f, "img" == s && (a.alt && !a.title && (a.title = ""), a.title && !a.alt && (a.alt = a.title), 
a.alt || (a.alt = ""), "" === a.alt && (a.role = "presentation"), a.src || (!0 === l.nosrc_substitute ? a.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" : l.nosrc_substitute && (a.src = l.nosrc_substitute))), 
"input" == s && (a.type || (a.type = "text")), "main" == s && (a.role || (a.role = "main")), 
"html" == s && (n += "<!DOCTYPE html>"), o.bemto_custom_tag.call({
block: function() {
i && i && i();
},
attributes: a
}, s, t), "list" === k[r - 1] && "li" != s && (n += "</li>");
};
var w = [], k = [ "block" ];
o.b = i = function(t) {
var i = this && this.block, n = this && this.attributes || {}, a = x();
t && void 0 !== t.prefix && (a.prefix = t.prefix);
var l = t && t.tag || ("string" == typeof t ? t : ""), c = t && t.isElement, u = t && t.metadata, f = !1;
if (n.class) {
var p = n.class;
p instanceof e && (p = p.join(" ")), p = p.split(" ");
var m = [], d = !0, h = [];
if (function() {
var e = p;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t], o = {}, u = m[m.length - 1], _ = !1;
if (n.match(/^[A-Z-]+[A-Z0-9-]?$/)) l = n.toLowerCase(); else if (d && c && (o.context = w[w.length - 1]), 
(x = n.match(new r("^(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && u && u.name) u.modifiers || (u.modifiers = []), 
u.modifiers.push(x[1]); else {
(k = n.match(new r("^(?!" + a.modifier + "[A-Za-z0-9])" + a.element + "(.+)$"))) && (o.context = w[w.length - 1], 
n = k[1]), (A = n.match(new r("^(.*[A-Za-z0-9])(?!" + a.modifier + "$)" + a.element + "$"))) && (n = A[1], 
o.is_context = !0, _ = !0, f = !0, c = !1), (E = n.match(new r("^(.*?[A-Za-z0-9])(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && (n = E[1], 
o.modifiers || (o.modifiers = []), o.modifiers.push(E[2]));
var g = "", v = "()?";
if (a.prefix) {
"string" == typeof (O = a.prefix) && (O = {
"": O
});
var y = [];
O instanceof s && (function() {
var e = O;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
} else {
i = 0;
for (var t in e) {
i++;
n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
}
}
}.call(this), v = "(" + y.join("|") + ")?"), (Z = n.match(new r("^" + v + "([A-Za-z0-9]+.*)$"))) && (n = Z[2], 
g = Z[1] || "", void 0 !== (g = O[g]) && !0 !== g || (g = Z[1]));
}
o.prefix = (g || "").replace(/\-/g, "%DASH%").replace(/\_/g, "%UNDERSCORE%"), _ && n.match(/^[a-zA-Z0-9]+.*/) && h.push(o.context ? o.context + a.element + n : o.prefix + n), 
o.name = n, d = !1, o.context && o.context.length > 1 ? function() {
var e = o.context;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
(a = b(o)).context = [ n ], m.push(a);
} else {
i = 0;
for (var t in e) {
i++;
var a;
n = e[t];
(a = b(o)).context = [ n ], m.push(a);
}
}
}.call(this) : m.push(o);
}
} else {
i = 0;
for (var t in e) {
i++;
var x;
n = e[t], o = {}, u = m[m.length - 1], _ = !1;
if (n.match(/^[A-Z-]+[A-Z0-9-]?$/)) l = n.toLowerCase(); else if (d && c && (o.context = w[w.length - 1]), 
(x = n.match(new r("^(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && u && u.name) u.modifiers || (u.modifiers = []), 
u.modifiers.push(x[1]); else {
var k, A, E;
(k = n.match(new r("^(?!" + a.modifier + "[A-Za-z0-9])" + a.element + "(.+)$"))) && (o.context = w[w.length - 1], 
n = k[1]), (A = n.match(new r("^(.*[A-Za-z0-9])(?!" + a.modifier + "$)" + a.element + "$"))) && (n = A[1], 
o.is_context = !0, _ = !0, f = !0, c = !1), (E = n.match(new r("^(.*?[A-Za-z0-9])(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && (n = E[1], 
o.modifiers || (o.modifiers = []), o.modifiers.push(E[2]));
g = "", v = "()?";
if (a.prefix) {
var O;
"string" == typeof (O = a.prefix) && (O = {
"": O
});
var Z;
y = [];
O instanceof s && (function() {
var e = O;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
} else {
i = 0;
for (var t in e) {
i++;
n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
}
}
}.call(this), v = "(" + y.join("|") + ")?"), (Z = n.match(new r("^" + v + "([A-Za-z0-9]+.*)$"))) && (n = Z[2], 
g = Z[1] || "", void 0 !== (g = O[g]) && !0 !== g || (g = Z[1]));
}
o.prefix = (g || "").replace(/\-/g, "%DASH%").replace(/\_/g, "%UNDERSCORE%"), _ && n.match(/^[a-zA-Z0-9]+.*/) && h.push(o.context ? o.context + a.element + n : o.prefix + n), 
o.name = n, d = !1, o.context && o.context.length > 1 ? function() {
var e = o.context;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
(a = b(o)).context = [ n ], m.push(a);
} else {
i = 0;
for (var t in e) {
i++;
var a;
n = e[t];
(a = b(o)).context = [ n ], m.push(a);
}
}
}.call(this) : m.push(o);
}
}
}
}.call(this), !c && !h.length && m[0] && m[0].name && m[0].name.match(/^[a-zA-Z0-9]+.*/) && (m[0].is_context = !0, 
h.push(m[0].context ? m[0].context + a.element + m[0].name : m[0].prefix + m[0].name), 
f = !0), h.length && (a.flat_elements && function() {
var e = h;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
(n = e[t].match(new r("^(.*?[A-Za-z0-9])(?!" + a.modifier + "[A-Za-z0-9])" + a.element + ".+$"))) && (h[t] = n[1]);
} else {
i = 0;
for (var t in e) {
var n;
i++, (n = e[t].match(new r("^(.*?[A-Za-z0-9])(?!" + a.modifier + "[A-Za-z0-9])" + a.element + ".+$"))) && (h[t] = n[1]);
}
}
}.call(this), w[w.length] = h), m.length) {
var _ = [];
(function() {
var e = m;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
if ((o = e[t]).name) {
var n = o.prefix;
o.context && (n = o.context + a.output_element), _.push(n + o.name), o.modifiers && function() {
var e = o.modifiers;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var l = e[t];
_.push(n + o.name + a.output_modifier + l);
} else {
i = 0;
for (var t in e) {
i++;
l = e[t];
_.push(n + o.name + a.output_modifier + l);
}
}
}.call(this);
}
} else {
i = 0;
for (var t in e) {
var o;
if (i++, (o = e[t]).name) {
n = o.prefix;
o.context && (n = o.context + a.output_element), _.push(n + o.name), o.modifiers && function() {
var e = o.modifiers;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var l = e[t];
_.push(n + o.name + a.output_modifier + l);
} else {
i = 0;
for (var t in e) {
i++;
l = e[t];
_.push(n + o.name + a.output_modifier + l);
}
}
}.call(this);
}
}
}
}).call(this);
var g = a.class_delimiter;
g = g ? " " + g + " " : " ", n.class = _.join(g).replace(/%DASH%/g, "-").replace(/%UNDERSCORE%/g, "_");
} else n.class = void 0;
}
i ? o.bemto_tag.call({
block: function() {
i && i();
},
attributes: n
}, l, u) : o.bemto_tag.call({
attributes: n
}, l, u), !c && f && (w = w.splice(0, w.length - 1)), k = k.splice(0, k.length - 1);
}, o.e = i = function(e) {
var t = this && this.block, i = this && this.attributes || {};
(e = e && "string" == typeof e ? {
tag: e
} : e || {}).isElement = !0, o.b.call({
block: function() {
t && t();
},
attributes: i
}, e);
}, o.b.call({
block: function() {
o.e.call({
block: function() {
m ? o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.login_form.title")) ? "" : i);
},
attributes: {
class: "title"
}
}, "h4"), o.e.call({
block: function() {
n += "/";
},
attributes: {
class: "header-delimiter"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.login_form.registration_link")) ? "" : i);
},
attributes: {
class: "button-link __register",
type: "button",
"data-switch": "register-form"
}
}, "button");
},
attributes: {
class: "header-aside"
}
});
},
attributes: {
class: "line __header"
}
}) : h ? n = n + "<p>" + (null == (i = h) ? "" : i) + "</p>" : (n = n + "<p>" + a.escape(null == (i = _("auth.if_you_dont_have_account")) ? "" : i) + "&nbsp;", 
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.signup")) ? "" : i);
},
attributes: {
class: "button-link __register",
type: "button",
"data-switch": "register-form"
}
}, "button"), n += "</p>"), o.e.call({
block: function() {
o.e.call({
attributes: {
class: "line __notification",
"data-notification": a.escape(!0)
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.email_field_label") + ":") ? "" : i);
},
attributes: {
class: "label",
for: "auth-email"
}
}, "label"), o.b.call({
block: function() {
o.e.call({
attributes: {
class: "control",
id: "auth-email",
name: "email",
type: "email",
autofocus: a.escape(!0),
tabindex: "1"
}
}, "input");
},
attributes: {
class: "text-input __input"
}
}, "span");
},
attributes: {
class: "form-control"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.password_field_label") + ":") ? "" : i);
},
attributes: {
class: "label",
for: "auth-password"
}
}, "label"), o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.login_form.forgot")) ? "" : i);
},
attributes: {
class: "aside __forgot __button-link",
type: "button",
"data-switch": "forgot-form",
tabindex: "4"
}
}, "button"), o.b.call({
block: function() {
o.e.call({
attributes: {
class: "control",
id: "auth-password",
type: "password",
name: "password",
tabindex: "2"
}
}, "input");
},
attributes: {
class: "text-input _with-aside __input"
}
}, "span");
},
attributes: {
class: "form-control"
}
}), o.e.call({
block: function() {
o.b.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.login_form.login_button")) ? "" : i);
},
attributes: {
class: "text"
}
}, "span");
},
attributes: {
class: "button _action",
type: "submit",
tabindex: "3"
}
}, "button"), m && o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.login_form.cancel")) ? "" : i);
},
attributes: {
class: "close-link tablet-only modal__close",
href: "#"
}
}, "a");
},
attributes: {
class: "form-control __submit"
}
});
},
attributes: {
class: "line __row __row-wrap"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = _("auth.login_form.login_using_socialnetworks")) ? "" : i);
},
attributes: {
class: "social-logins-title"
}
}, "h5"), n += a.escape(null == (i = " ") ? "" : i), function() {
var e = d;
if ("number" == typeof e.length) for (var t = 0, l = e.length; t < l; t++) {
let l = [ "social-login", "_" + (s = e[t]).id, "__social-login" ];
o.b.call({
block: function() {
n += a.escape(null == (i = s.name) ? "" : i);
},
attributes: {
class: a.classes([ l ], [ !0 ]),
"data-provider": a.escape(s.id)
}
}, "button"), n += a.escape(null == (i = " ") ? "" : i);
} else {
l = 0;
for (var t in e) {
var s;
l++;
let r = [ "social-login", "_" + (s = e[t]).id, "__social-login" ];
o.b.call({
block: function() {
n += a.escape(null == (i = s.name) ? "" : i);
},
attributes: {
class: a.classes([ r ], [ !0 ]),
"data-provider": a.escape(s.id)
}
}, "button"), n += a.escape(null == (i = " ") ? "" : i);
}
}
}.call(this);
},
attributes: {
class: "line __social-logins"
}
});
},
attributes: {
class: "body"
}
});
},
attributes: {
class: "form",
action: "#"
}
}, "form");
},
attributes: {
class: a.classes([ [ "login-form", m ? "_modal" : "_inline" ] ], [ !0 ]),
"data-form": "login"
}
});
}.call(this, "Array" in l ? l.Array : "undefined" != typeof Array ? Array : void 0, "Date" in l ? l.Date : "undefined" != typeof Date ? Date : void 0, "Error" in l ? l.Error : "undefined" != typeof Error ? Error : void 0, "Object" in l ? l.Object : "undefined" != typeof Object ? Object : void 0, "RegExp" in l ? l.RegExp : "undefined" != typeof RegExp ? RegExp : void 0, "bemto_settings_default_tag" in l ? l.bemto_settings_default_tag : "undefined" != typeof bemto_settings_default_tag ? bemto_settings_default_tag : void 0, "bemto_settings_element" in l ? l.bemto_settings_element : "undefined" != typeof bemto_settings_element ? bemto_settings_element : void 0, "bemto_settings_modifier" in l ? l.bemto_settings_modifier : "undefined" != typeof bemto_settings_modifier ? bemto_settings_modifier : void 0, "bemto_settings_prefix" in l ? l.bemto_settings_prefix : "undefined" != typeof bemto_settings_prefix ? bemto_settings_prefix : void 0, "inModal" in l ? l.inModal : "undefined" != typeof inModal ? inModal : void 0, "providers" in l ? l.providers : [ {
name: "Github",
id: "github"
}, {
name: "Discord",
id: "discord"
}, {
name: "Facebook",
id: "facebook"
}, {
name: "Google",
id: "google"
}, {
name: "Яндекс",
id: "yandex"
}, {
name: "Вконтакте",
id: "vkontakte"
} ], "subtitle" in l ? l.subtitle : "undefined" != typeof subtitle ? subtitle : void 0, "t" in l ? l.t : "undefined" != typeof t ? t : void 0), 
n;
};
},
1898: function(e, i, n) {
var a = n(7766);
e.exports = function(e) {
var i, n = "", o = {}, l = e || {};
return function(e, t, l, s, r, c, u, f, p, m, d, h) {
var _ = function(i) {
var n;
if (null == i || "object" != typeof i) return i;
if (i instanceof t) return (n = new t).setTime(i.getTime()), n;
if (i instanceof e) {
n = [];
for (var a = 0, o = i.length; a < o; a++) n[a] = _(i[a]);
return n;
}
if (i instanceof s) {
for (var r in n = {}, i) i.hasOwnProperty(r) && (n[r] = _(i[r]));
return n;
}
throw new l("Unable to copy obj! Its type isn't supported.");
}, b = {
hr: {
type: "self_closing"
},
br: {
type: "self_closing"
},
wbr: {
type: "self_closing"
},
source: {
type: "self_closing"
},
img: {
type: "self_closing"
},
input: {
type: "self_closing"
},
a: {
type: "inline"
},
abbr: {
type: "inline"
},
acronym: {
type: "inline"
},
b: {
type: "inline"
},
code: {
type: "inline"
},
em: {
type: "inline"
},
font: {
type: "inline"
},
i: {
type: "inline"
},
ins: {
type: "inline"
},
kbd: {
type: "inline"
},
map: {
type: "inline"
},
pre: {
type: "inline"
},
samp: {
type: "inline"
},
small: {
type: "inline"
},
span: {
type: "inline"
},
strong: {
type: "inline"
},
sub: {
type: "inline"
},
sup: {
type: "inline"
},
textarea: {
type: "inline"
},
time: {
type: "inline"
},
label: {
content_type: "inline"
},
p: {
content_type: "inline"
},
h1: {
content_type: "inline"
},
h2: {
content_type: "inline"
},
h3: {
content_type: "inline"
},
h4: {
content_type: "inline"
},
h5: {
content_type: "inline"
},
h6: {
content_type: "inline"
},
ul: {
content_type: "list"
},
ol: {
content_type: "list"
},
select: {
content_type: "optionlist"
},
datalist: {
content_type: "optionlist"
}
}, g = [ "element", "modifier" ], v = {
prefix: "",
element: "__",
modifier: "_",
default_tag: "div",
nosrc_substitute: !0,
flat_elements: !0,
class_delimiter: ""
}, y = function() {
var e = _(v);
void 0 !== p && (e.prefix = p), void 0 !== u && (e.element = u), void 0 !== f && (e.modifier = f), 
void 0 !== c && (e.default_tag = c);
for (var t = 0; t < g.length; t++) {
var i = g[t];
void 0 === e["output_" + i] && (e["output_" + i] = e[i]);
}
return e;
};
o.bemto_custom_inline_tag = i = function(e, t) {
var o = this && this.block, l = this && this.attributes || {};
if (t = t || !1, n += (null == (i = "<") ? "" : i) + a.escape(null == (i = e) ? "" : i), 
l) for (var s in l) l.hasOwnProperty(s) && !1 !== l[s] && void 0 !== l[s] && (n += a.escape(null == (i = " ") ? "" : i) + a.escape(null == (i = s) ? "" : i) + (null == (i = '="') ? "" : i) + (null == (i = !0 === l[s] ? s : l[s]) ? "" : i) + (null == (i = '"') ? "" : i));
t ? n += null == (i = "/>") ? "" : i : (n += null == (i = ">") ? "" : i, o && o(), 
n += (null == (i = "</") ? "" : i) + a.escape(null == (i = e) ? "" : i) + (null == (i = ">") ? "" : i));
}, o.bemto_custom_tag = i = function(e, t) {
var i = this && this.block, l = this && this.attributes || {};
t = t || {};
var s, r, c = !1;
switch ("/" === (e = e || "div").substr(-1) && (c = !0, e = e.slice(0, -1)), t.type || (r = "block", 
b[s = e] && (r = b[s].type || r), r)) {
case "inline":
o.bemto_custom_inline_tag.call({
block: function() {
i && i();
},
attributes: l
}, e);
break;

case "self_closing":
o.bemto_custom_inline_tag.call({
attributes: l
}, e, !0);
break;

default:
c ? n = n + "<" + e + a.attrs(l, !0) + "/>" : (n = n + "<" + e + a.attrs(l, !0) + ">", 
i && i(), n = n + "</" + e + ">");
}
}, o.bemto_tag = i = function(e, t) {
var i = this && this.block, a = this && this.attributes || {}, l = y();
t = t || {};
var s = e || l.default_tag, r = w.length;
e || ("inline" === w[r - 1] ? s = "span" : "list" === w[r - 1] ? s = "li" : "optionlist" === w[r - 1] && (s = "option")), 
e && "span" != e && "div" != e || (a.href && (s = "a"), a.for && (s = "label"), 
a.type ? s = i ? "button" : "input" : a.src && (s = "img")), "list" === w[r - 1] && "li" !== s ? n += "<li>" : "list" !== w[r - 1] && "pseudo-list" !== w[r - 1] && "li" === s ? (n += "<ul>", 
w[w.length] = "pseudo-list") : "pseudo-list" === w[r - 1] && "li" !== s && (n += "</ul>", 
w = w.splice(0, w.length - 1));
var c, u, f = t.content_type || (u = "block", b[c = s] && (u = b[c].content_type || b[c].type || u), 
u);
w[w.length] = f, "img" == s && (a.alt && !a.title && (a.title = ""), a.title && !a.alt && (a.alt = a.title), 
a.alt || (a.alt = ""), "" === a.alt && (a.role = "presentation"), a.src || (!0 === l.nosrc_substitute ? a.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" : l.nosrc_substitute && (a.src = l.nosrc_substitute))), 
"input" == s && (a.type || (a.type = "text")), "main" == s && (a.role || (a.role = "main")), 
"html" == s && (n += "<!DOCTYPE html>"), o.bemto_custom_tag.call({
block: function() {
i && i && i();
},
attributes: a
}, s, t), "list" === w[r - 1] && "li" != s && (n += "</li>");
};
var x = [], w = [ "block" ];
o.b = i = function(t) {
var i = this && this.block, n = this && this.attributes || {}, a = y();
t && void 0 !== t.prefix && (a.prefix = t.prefix);
var l = t && t.tag || ("string" == typeof t ? t : ""), c = t && t.isElement, u = t && t.metadata, f = !1;
if (n.class) {
var p = n.class;
p instanceof e && (p = p.join(" ")), p = p.split(" ");
var m = [], d = !0, h = [];
if (function() {
var e = p;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t], o = {}, u = m[m.length - 1], b = !1;
if (n.match(/^[A-Z-]+[A-Z0-9-]?$/)) l = n.toLowerCase(); else if (d && c && (o.context = x[x.length - 1]), 
(w = n.match(new r("^(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && u && u.name) u.modifiers || (u.modifiers = []), 
u.modifiers.push(w[1]); else {
(k = n.match(new r("^(?!" + a.modifier + "[A-Za-z0-9])" + a.element + "(.+)$"))) && (o.context = x[x.length - 1], 
n = k[1]), (A = n.match(new r("^(.*[A-Za-z0-9])(?!" + a.modifier + "$)" + a.element + "$"))) && (n = A[1], 
o.is_context = !0, b = !0, f = !0, c = !1), (E = n.match(new r("^(.*?[A-Za-z0-9])(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && (n = E[1], 
o.modifiers || (o.modifiers = []), o.modifiers.push(E[2]));
var g = "", v = "()?";
if (a.prefix) {
"string" == typeof (O = a.prefix) && (O = {
"": O
});
var y = [];
O instanceof s && (function() {
var e = O;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
} else {
i = 0;
for (var t in e) {
i++;
n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
}
}
}.call(this), v = "(" + y.join("|") + ")?"), (Z = n.match(new r("^" + v + "([A-Za-z0-9]+.*)$"))) && (n = Z[2], 
g = Z[1] || "", void 0 !== (g = O[g]) && !0 !== g || (g = Z[1]));
}
o.prefix = (g || "").replace(/\-/g, "%DASH%").replace(/\_/g, "%UNDERSCORE%"), b && n.match(/^[a-zA-Z0-9]+.*/) && h.push(o.context ? o.context + a.element + n : o.prefix + n), 
o.name = n, d = !1, o.context && o.context.length > 1 ? function() {
var e = o.context;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
(a = _(o)).context = [ n ], m.push(a);
} else {
i = 0;
for (var t in e) {
i++;
var a;
n = e[t];
(a = _(o)).context = [ n ], m.push(a);
}
}
}.call(this) : m.push(o);
}
} else {
i = 0;
for (var t in e) {
i++;
var w;
n = e[t], o = {}, u = m[m.length - 1], b = !1;
if (n.match(/^[A-Z-]+[A-Z0-9-]?$/)) l = n.toLowerCase(); else if (d && c && (o.context = x[x.length - 1]), 
(w = n.match(new r("^(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && u && u.name) u.modifiers || (u.modifiers = []), 
u.modifiers.push(w[1]); else {
var k, A, E;
(k = n.match(new r("^(?!" + a.modifier + "[A-Za-z0-9])" + a.element + "(.+)$"))) && (o.context = x[x.length - 1], 
n = k[1]), (A = n.match(new r("^(.*[A-Za-z0-9])(?!" + a.modifier + "$)" + a.element + "$"))) && (n = A[1], 
o.is_context = !0, b = !0, f = !0, c = !1), (E = n.match(new r("^(.*?[A-Za-z0-9])(?!" + a.element + "[A-Za-z0-9])" + a.modifier + "(.+)$"))) && (n = E[1], 
o.modifiers || (o.modifiers = []), o.modifiers.push(E[2]));
g = "", v = "()?";
if (a.prefix) {
var O;
"string" == typeof (O = a.prefix) && (O = {
"": O
});
var Z;
y = [];
O instanceof s && (function() {
var e = O;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
} else {
i = 0;
for (var t in e) {
i++;
n = e[t];
"string" == typeof t && "" != t && -1 == y.indexOf(t) && y.push(t), "string" == typeof n && "" != n && -1 == y.indexOf(n) && y.push(n);
}
}
}.call(this), v = "(" + y.join("|") + ")?"), (Z = n.match(new r("^" + v + "([A-Za-z0-9]+.*)$"))) && (n = Z[2], 
g = Z[1] || "", void 0 !== (g = O[g]) && !0 !== g || (g = Z[1]));
}
o.prefix = (g || "").replace(/\-/g, "%DASH%").replace(/\_/g, "%UNDERSCORE%"), b && n.match(/^[a-zA-Z0-9]+.*/) && h.push(o.context ? o.context + a.element + n : o.prefix + n), 
o.name = n, d = !1, o.context && o.context.length > 1 ? function() {
var e = o.context;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var n = e[t];
(a = _(o)).context = [ n ], m.push(a);
} else {
i = 0;
for (var t in e) {
i++;
var a;
n = e[t];
(a = _(o)).context = [ n ], m.push(a);
}
}
}.call(this) : m.push(o);
}
}
}
}.call(this), !c && !h.length && m[0] && m[0].name && m[0].name.match(/^[a-zA-Z0-9]+.*/) && (m[0].is_context = !0, 
h.push(m[0].context ? m[0].context + a.element + m[0].name : m[0].prefix + m[0].name), 
f = !0), h.length && (a.flat_elements && function() {
var e = h;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
(n = e[t].match(new r("^(.*?[A-Za-z0-9])(?!" + a.modifier + "[A-Za-z0-9])" + a.element + ".+$"))) && (h[t] = n[1]);
} else {
i = 0;
for (var t in e) {
var n;
i++, (n = e[t].match(new r("^(.*?[A-Za-z0-9])(?!" + a.modifier + "[A-Za-z0-9])" + a.element + ".+$"))) && (h[t] = n[1]);
}
}
}.call(this), x[x.length] = h), m.length) {
var b = [];
(function() {
var e = m;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
if ((o = e[t]).name) {
var n = o.prefix;
o.context && (n = o.context + a.output_element), b.push(n + o.name), o.modifiers && function() {
var e = o.modifiers;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var l = e[t];
b.push(n + o.name + a.output_modifier + l);
} else {
i = 0;
for (var t in e) {
i++;
l = e[t];
b.push(n + o.name + a.output_modifier + l);
}
}
}.call(this);
}
} else {
i = 0;
for (var t in e) {
var o;
if (i++, (o = e[t]).name) {
n = o.prefix;
o.context && (n = o.context + a.output_element), b.push(n + o.name), o.modifiers && function() {
var e = o.modifiers;
if ("number" == typeof e.length) for (var t = 0, i = e.length; t < i; t++) {
var l = e[t];
b.push(n + o.name + a.output_modifier + l);
} else {
i = 0;
for (var t in e) {
i++;
l = e[t];
b.push(n + o.name + a.output_modifier + l);
}
}
}.call(this);
}
}
}
}).call(this);
var g = a.class_delimiter;
g = g ? " " + g + " " : " ", n.class = b.join(g).replace(/%DASH%/g, "-").replace(/%UNDERSCORE%/g, "_");
} else n.class = void 0;
}
i ? o.bemto_tag.call({
block: function() {
i && i();
},
attributes: n
}, l, u) : o.bemto_tag.call({
attributes: n
}, l, u), !c && f && (x = x.splice(0, x.length - 1)), w = w.splice(0, w.length - 1);
}, o.e = i = function(e) {
var t = this && this.block, i = this && this.attributes || {};
(e = e && "string" == typeof e ? {
tag: e
} : e || {}).isElement = !0, o.b.call({
block: function() {
t && t();
},
attributes: i
}, e);
}, o.b.call({
block: function() {
o.e.call({
block: function() {
m ? o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = h("auth.signup_form.title")) ? "" : i);
},
attributes: {
class: "title"
}
}, "h4"), o.e.call({
block: function() {
n += "/";
},
attributes: {
class: "header-delimiter"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = h("auth.signup_form.login_link")) ? "" : i);
},
attributes: {
class: "button-link __login",
type: "button",
"data-switch": "login-form"
}
}, "button");
},
attributes: {
class: "header-aside"
}
});
},
attributes: {
class: "line __header"
}
}) : (n = n + "<p>" + a.escape(null == (i = h("auth.signup_form.if_you_already_have_account")) ? "" : i) + "&nbsp;", 
o.e.call({
block: function() {
n += a.escape(null == (i = h("auth.signup_form.login")) ? "" : i);
},
attributes: {
class: "button-link",
type: "button",
"data-switch": "login-form"
}
}, "button"), n += "</p>"), o.e.call({
block: function() {
o.e.call({
attributes: {
class: "line __notification",
"data-notification": a.escape(!0)
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
o.e.call({
block: function() {
n = n + a.escape(null == (i = h("auth.email_field_label")) ? "" : i) + ":";
},
attributes: {
class: "label",
for: "register-email"
}
}, "label"), o.b.call({
block: function() {
o.e.call({
attributes: {
class: "control",
id: "register-email",
name: "email",
type: "email",
required: a.escape(!0),
autofocus: a.escape(!0)
}
}, "input");
},
attributes: {
class: "text-input __input"
}
}, "span");
},
attributes: {
class: "form-control"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n = n + a.escape(null == (i = h("auth.signup_form.displayName_field_label")) ? "" : i) + ":";
},
attributes: {
class: "label",
for: "register-displayName"
}
}, "label"), o.b.call({
block: function() {
o.e.call({
attributes: {
class: "control",
id: "register-displayName",
name: "displayName",
required: a.escape(!0)
}
}, "input");
},
attributes: {
class: "text-input __input"
}
}, "span");
},
attributes: {
class: "form-control"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n = n + a.escape(null == (i = h("auth.password_field_label")) ? "" : i) + ":";
},
attributes: {
class: "label",
for: "register-password"
}
}, "label"), o.b.call({
block: function() {
o.e.call({
attributes: {
class: "control",
id: "register-password",
type: "password",
name: "password",
required: a.escape(!0),
minlength: "4"
}
}, "input");
},
attributes: {
class: "text-input __input"
}
}, "span");
},
attributes: {
class: "form-control"
}
});
},
attributes: {
class: "line __row"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
o.e.call({
attributes: {
class: "agreement-control",
id: "accept-agreement",
type: "checkbox",
"data-action-accept-agreements": a.escape(!0)
}
}, "input"), n += null == (i = h("auth.signup_form.register_accept")) ? "" : i;
},
attributes: {
class: "agreement-label",
for: "accept-agreement"
}
}, "label");
},
attributes: {
class: "line __agreement"
}
}), o.e.call({
block: function() {
o.e.call({
attributes: {
class: "recaptcha"
}
});
},
attributes: {
class: "line"
}
}), o.e.call({
block: function() {
o.b.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = h("auth.signup_form.signup")) ? "" : i);
},
attributes: {
class: "text"
}
}, "span");
},
attributes: {
class: "button _action submit",
type: "submit",
disabled: "true"
}
}, "button"), m && o.e.call({
block: function() {
n += a.escape(null == (i = h("auth.signup_form.cancel")) ? "" : i);
},
attributes: {
class: "close-link tablet-only modal__close",
href: "#"
}
}, "a");
},
attributes: {
class: "line __footer"
}
}), o.e.call({
block: function() {
o.e.call({
block: function() {
n += a.escape(null == (i = h("auth.login_form.login_using_socialnetworks")) ? "" : i);
},
attributes: {
class: "social-logins-title"
}
}, "h5"), n += a.escape(null == (i = " ") ? "" : i), function() {
var e = d;
if ("number" == typeof e.length) for (var t = 0, l = e.length; t < l; t++) {
let l = [ "social-login", "_" + (s = e[t]).id, "__social-login" ];
o.b.call({
block: function() {
n += a.escape(null == (i = s.name) ? "" : i);
},
attributes: {
class: a.classes([ l ], [ !0 ]),
"data-provider": a.escape(s.id)
}
}, "button"), n += a.escape(null == (i = " ") ? "" : i);
} else {
l = 0;
for (var t in e) {
var s;
l++;
let r = [ "social-login", "_" + (s = e[t]).id, "__social-login" ];
o.b.call({
block: function() {
n += a.escape(null == (i = s.name) ? "" : i);
},
attributes: {
class: a.classes([ r ], [ !0 ]),
"data-provider": a.escape(s.id)
}
}, "button"), n += a.escape(null == (i = " ") ? "" : i);
}
}
}.call(this);
},
attributes: {
class: "line __social-logins"
}
});
},
attributes: {
class: "body"
}
});
},
attributes: {
class: "form",
action: "#",
"data-form": "register"
}
}, "form");
},
attributes: {
class: a.classes([ [ "login-form", m ? "_modal" : "_inline" ] ], [ !0 ])
}
});
}.call(this, "Array" in l ? l.Array : "undefined" != typeof Array ? Array : void 0, "Date" in l ? l.Date : "undefined" != typeof Date ? Date : void 0, "Error" in l ? l.Error : "undefined" != typeof Error ? Error : void 0, "Object" in l ? l.Object : "undefined" != typeof Object ? Object : void 0, "RegExp" in l ? l.RegExp : "undefined" != typeof RegExp ? RegExp : void 0, "bemto_settings_default_tag" in l ? l.bemto_settings_default_tag : "undefined" != typeof bemto_settings_default_tag ? bemto_settings_default_tag : void 0, "bemto_settings_element" in l ? l.bemto_settings_element : "undefined" != typeof bemto_settings_element ? bemto_settings_element : void 0, "bemto_settings_modifier" in l ? l.bemto_settings_modifier : "undefined" != typeof bemto_settings_modifier ? bemto_settings_modifier : void 0, "bemto_settings_prefix" in l ? l.bemto_settings_prefix : "undefined" != typeof bemto_settings_prefix ? bemto_settings_prefix : void 0, "inModal" in l ? l.inModal : "undefined" != typeof inModal ? inModal : void 0, "providers" in l ? l.providers : [ {
name: "Github",
id: "github"
}, {
name: "Discord",
id: "discord"
}, {
name: "Facebook",
id: "facebook"
}, {
name: "Google",
id: "google"
}, {
name: "Яндекс",
id: "yandex"
}, {
name: "Вконтакте",
id: "vkontakte"
} ], "t" in l ? l.t : "undefined" != typeof t ? t : void 0), n;
};
},
9321: function(e, t, i) {
"use strict";
i.r(t), t.default = {
site: {
privacy_policy: "политика конфиденциальности",
terms: "пользовательское соглашение",
banner_bottom: 'Проводим <a href="/courses">курсы по JavaScript и фреймворкам</a>.',
action_required: "Требуется действие",
gdpr_dialog: {
title: "Этот сайт использует cookie",
text: 'Мы используем браузерные технологии, такие как cookie и local storage для хранения ваших предпочтений. Вы принимаете <a href="/privacy">политику конфиденциальности</a> и <a href="/terms">соглашение пользователя</a>?',
accept: "Принять",
cancel: "Отмена"
},
theme: {
light: "Светлая тема",
dark: "Тёмная тема",
change: "Сменить тему оформления"
},
toolbar: {
lang_switcher: {
cta_text: 'Мы хотим сделать этот проект с открытым исходным кодом доступным для людей во всем мире. Пожалуйста, <a href="https://javascript.info/translate#help" rel="noopener noreferrer" target="_blank">помогите нам перевести</a> это руководство на другие языки.',
footer_text: "количество контента, переведенное на соотвествующий язык",
old_version: "Опубликована полная, но предыдущая версия учебника."
},
logo: {
normal: {
svg: "sitetoolbar__logo_ru.svg",
width: 171
},
"normal-white": {
svg: "sitetoolbar__logo_ru-white.svg"
},
small: {
svg: "sitetoolbar__logo_small_ru.svg",
width: 80
},
"small-white": {
svg: "sitetoolbar__logo_small_ru-white.svg"
}
},
sections: [ {
slug: "tutorial",
url: "/",
title: "Учебник"
}, {
slug: "courses",
title: "Курсы"
}, {
url: "https://javascript.ru/forum/",
title: "Форум"
}, {
slug: "quiz",
title: "Тесты знаний"
} ],
sections_bak: [ {
slug: "jobs",
title: "Стажировки"
} ],
buy_ebook_extra: "Купить",
buy_ebook: "EPUB/PDF",
search_placeholder: "Искать на Javascript.ru",
search_button: "Найти",
public_profile: "Публичный профиль",
account: "Аккаунт",
notifications: "Уведомления",
admin: "Админ",
logout: "Выйти"
},
sorry_old_browser: "Извините, Internet Explorer не поддерживается, пожалуйста используйте более новый браузер.",
contact_us: "связаться с нами",
about_the_project: "о проекте",
ilya_kantor: "Илья Кантор",
comments: "Комментарии",
loading: "Загружается...",
search: "Искать",
share: "Поделиться",
read_before_commenting: "перед тем как писать…",
last_updated_at: "Последнее обновление: #{date}",
"tablet-menu": {
choose_section: "Выберите раздел",
search_placeholder: "Поиск в учебнике",
search_button: "Поиск"
},
comment: {
help: [ 'Если вам кажется, что в статье что-то не так - вместо комментария напишите <a href="https://github.com/javascript-tutorial/ru.javascript.info/issues/new">на GitHub</a>.', "Для одной строки кода используйте тег <code>&lt;code&gt;</code>, для нескольких строк кода&nbsp;&mdash; тег <code>&lt;pre&gt;</code>, если больше 10 строк&nbsp;&mdash; ссылку на песочницу (<a href='https://plnkr.co/edit/?p=preview'>plnkr</a>, <a href='http://jsbin.com'>JSBin</a>, <a href='http://codepen.io'>codepen</a>…)", "Если что-то непонятно в статье&nbsp;&mdash; пишите, что именно и с какого места." ]
},
meta: {
description: "Современный учебник JavaScript, начиная с основ, включающий в себя много тонкостей и фишек JavaScript/DOM."
},
edit_on_github: "Редактировать на GitHub",
error: "ошибка",
close: "закрыть",
hide_forever: "не показывать",
hidden_forever: "Эта информация больше не будет выводиться.",
subscribe: {
title: "Следите за обновлениями javascript.ru",
text: "Мы не рассылаем рекламу, все только по делу. Вы сами выбираете, что получать:",
agreement: 'Подписываясь на рассылку, вы соглашаетесь с <a href="#{link}" target="_blank">пользовательским соглашением</a>.',
button: "Подписаться",
button_unsubscribe: "Отписаться от всех",
common_updates: "Общие обновления",
common_updates_text: "новые курсы, интенсивы, выпуски статей и скринкастов",
your_email: "ваш@email",
newsletters: "рассылка,рассылки,рассылок",
no_selected: "Не выбрано"
},
form: {
value_must_not_be_empty: "Значение не должно быть пустым.",
value_is_too_long: "Значение слишком длинное.",
value_is_too_short: "Значение слишком короткое.",
invalid_email: "Некорректный email.",
invalid_value: "Некорректное значение.",
invalid_autocomplete: "Пожалуйста, выберите значение из списка",
invalid_date: "Дата неверна, формат: дд.мм.гггг.",
invalid_range: "Такой даты здесь не может быть.",
save: "Сохранить",
upload_file: "Загрузить файл",
cancel: "Отмена",
server_error: "Ошибка загрузки, статус"
}
}
};
},
3342: function(e, t, i) {
"use strict";
i.r(t), t.default = {
if_you_dont_have_account: "Если у вас еще нет аккаунта, вы можете",
signup: "зарегистрироваться",
email_field_label: "Email",
password_field_label: "Пароль",
login_form: {
title: "Вход",
registration_link: "Регистрация",
forgot: "Забыли?",
login_button: "Войти",
cancel: "Отмена",
login_using_socialnetworks: "Вход через социальные сети",
test_mode: 'Авторизация работает в тестовом режиме. О любых проблемах и странностях сообщайте, пожалуйста, на <a href="https://github.com/javascript-tutorial/en.javascript.info/issues/new">github</a>.'
},
signup_form: {
title: "Регистрация",
login_link: "Вход",
if_you_already_have_account: "Если у вас уже есть аккаунт, вы можете",
login: "войти",
displayName_field_label: "Имя пользователя",
signup: "Зарегистрироваться",
cancel: "Отмена",
register_accept: 'Я прочитал и согласен с <a href="/terms">пользовательским соглашением</a> и <a href="/privacy">политикой конфиденциальности</a>.',
email_field_label: "E-mail",
password_field_label: "Пароль"
},
login_guard: {
finalize_subtitle_order: "<p>В целях безопасности, для доступа к данным заказа на сайте создан аккаунт с логином EMAIL.</p><p>Пожалуйста, выберите имя пользователя и пароль.</p>",
finalize_subtitle: "<p>В целях безопасности, для доступа к данным на сайте создан аккаунт с логином EMAIL.</p><p>Пожалуйста, выберите имя пользователя и пароль.</p>",
login_subtitle_order: "<p>В целях безопасности для доступа к данным заказов необходимо войти на сайт.</p>",
login_subtitle: "<p>В целях безопасности для доступа к данным необходимо войти на сайт.</p>"
},
email_not_verified: "Email не подтверждён",
auth_form: {
letter_resend: "<p>Письмо-подтверждение отправлено ещё раз.</p> <p><a href='#' data-action-verify-email='#{email}'>перезапросить подтверждение.</a></p>\n",
enter_email: "Введите, пожалуста, email.",
enter_displayname: "Введите, пожалуста, имя пользователя.",
enter_password: "Введите, пожалуста, пароль.",
letter_sent: "<p>С адреса #{notifyEmail} отправлено письмо со ссылкой-подтверждением.</p> <p><a href='#' data-action-verify-email='#{email}'>перезапросить подтверждение.</a></p>\n",
unknown_error: "Неизвестный статус ответа сервера",
forbidden: "Действие запрещено.",
auth_reject: "Отказ в авторизации.",
enter_captcha: "Подтвердите, пожалуйста, что вы не робот (капча)."
},
forgot: {
no_such_user: "Пользователь с таким email не зарегистрирован",
access_recovery: "Восстановление доступа",
letter_sent: "На вашу почту отправлено письмо со ссылкой на смену пароля."
},
forgot_email: {
title: "Восстановление доступа на javascript.ru",
text: "Для восстановления доступа перейдите, пожалуйста, по ссылке"
},
forgot_recover: {
invalid_link: "Вы перешли по устаревшей или недействительной ссылке на восстановление",
invalid_link_received: "Ваша ссылка на восстановление недействительна или устарела",
password_empty_error: "Пароль не должен быть пустым.",
password_length_error: "Пароль должен содержать минимум 4 символа.",
title: "Восстановление пароля",
close: "Закрыть",
new_password: "Новый пароль",
save_password: "Сохранить пароль"
},
confirm_activity: {
subject: "Привет! Пожалуйста, подтвердите ваши данные",
text: "Пожалуйста, подтвердите, что вы человек, а не бот, перейдя по ссылке в данном в письме. Обратите внимание, что при отсутствии подтверждения в течение 7 дней ваш аккаунт будет удален.",
invalid_link: "Вы перешли по устаревшей или недействительной ссылке подтверждения.",
success_text: "Поздравляем! Вы успешно подтвердили, что вы человек.",
already_confirmed_text: "Спасибо! Вы уже подтвердили, что вы человек.",
success_link: "Вернуться на главную"
},
login: {
title: "Авторизация"
},
register: {
already_exists: 'Если он ваш, то можно <a data-switch="login-form" href="#">войти</a> или <a data-switch="forgot-form" href="#">восстановить пароль</a>.\n',
confirm_email: "Подтверждение email",
email_sent_error: "Ошибка отправки email.",
email_title: "Подтверждение email на #{host}",
goto_link: "Для завершения регистрации перейдите, пожалуйста, по ссылке"
},
finalize_new_user: {
password_please: "Укажите имя и пароль для нового пользователя.",
username: "Имя нового пользователя",
password: "Выберите пароль"
},
reverify: {
email_empty_error: "Не указан email пользователя.",
no_such_user: "Нет такого пользователя.",
email_already_confirmed: "Ваш Email уже подтверждён.",
email_subject: "Подтверждение email",
sending_email_error: "На сервере ошибка отправки email."
},
verify: {
invalid_link: "Ссылка подтверждения недействительна или устарела",
email_already_taken: "Изменение email невозможно, адрес уже занят.",
email_already_verified: "Изменений не произведено: ваш email и так верифицирован, его смена не запрашивалась.",
no_password: "Не указан пароль"
},
authenticateByProfile: {
entrance_is_forbidden: "Вход по этому профилю не разрешён, извините.",
not_enough_data: "Недостаточно данных, разрешите их передачу, пожалуйста."
},
must_not_be_authenticated: "Это действие доступно только для неавторизованных посетителей.",
must_be_authenticated: "Для доступа к этой странице нужна авторизация",
forgot_form: {
title: "Восстановление пароля",
do_recovery: "Восстановить пароль",
login: "Вход",
registration: "Регистрация",
cancel: "Отмена"
},
local_strategy: {
need_email: "Укажите email.",
need_password: "Укажите пароль.",
no_user: "Нет такого пользователя.",
wrong_password: "Пароль неверен или он устарел, его можно заменить при помощи <a href='#' data-switch='forgot-form'>восстановления пароля</a>.",
email_not_confirmed: 'Ваш email не подтверждён, проверьте почту. Также можно <a href="#" data-action-verify-email="#{email}">запросить подтверждение заново</a>.'
},
facebook_strategy: {
no_email_error: "При входе разрешите доступ к email. Он используется для идентификации пользователя.",
request_error: "Ошибка в запросе к Facebook"
},
discord_strategy: {
error_connection: "Ошибка связи с сервером Discord.",
email_not_verified: "Почта в профиле Discord должна быть подтверждена.",
no_email: "Нужно указать и подтвердить email в профиле Discord."
},
github_strategy: {
error_connection: "Ошибка связи с сервером github.",
email_not_confirmed: "Почта на github должна быть подтверждена."
},
capcha_error: "Пожалуйста, подтвердите, что вы не робот.",
accept_agreements: {
title: "Пользовательское соглашение",
complete_registration: "Завершить регистрацию",
cancel: "Отменить",
need_accept_agreements: 'Для работы с сайтом необходимо принять <a href="/agreement", target="_blank">пользовательское соглашение</a>'
}
};
},
5660: function(e, t, i) {
"use strict";
i.r(t), t.default = {
server_connection_error: "Ошибка связи с сервером.",
server_request_timeout: "Превышено максимально допустимое время ожидания ответа от сервера.",
request_aborted: "Запрос был прерван.",
no_response: "Не получен ответ от сервера.",
server_error: "Ошибка на стороне сервера (код #{status}), попытайтесь позднее.",
server_error_info: "Ошибка на стороне сервера (код #{status}). #{info}.",
invalid_format: "Некорректный формат ответа от сервера."
};
},
3365: function() {}
} ]);
//# sourceMappingURL=authClient-616.0b4c045c387514d83d68.js.map