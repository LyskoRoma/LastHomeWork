var footer;

!function() {
var e = {
907: function(e) {
e.exports = {
lang: "ru",
localCurrency: "RUB",
shopCurrency: "RUB",
env: "production",
rateShopTo: void 0,
countryCode,
ordersMail: "orders@javascript.info",
providers: [ {
name: "Github",
id: "github"
}, {
name: "Discord",
id: "discord"
}, {
name: "Facebook",
id: "facebook"
}, {
name: "Google",
id: "google"
}, {
name: "Яндекс",
id: "yandex"
}, {
name: "Вконтакте",
id: "vkontakte"
} ],
stripeKey: "pk_live_51HXm0nFjeNqw1p5a3mjFxSeNHh8OL94IyGcp3PHbZVoNuYUYjlM57YtZMIAM1zrEd1F6WIKfFs67KbTemRdNIySo00KfWS1yhr",
paypalClientId: "Ac86EanyVr7jcO5a_EwTK2vg1MGguuNX27jI4oC120g8xLMuAKmayooEcpc-mODQd4Gsmm7yqA1C7NM-",
telegramBotId: 7532264140,
lookatCodeUrlBase: "https://lookatcode.com",
isRTL: void 0
};
},
595: function(e) {
e.exports = function() {
let e = document.querySelectorAll('figure img[src$=".png"]');
for (let t = 0; t < e.length; t++) {
let o = e[t];
o.onload = function() {
if (this.onload = null, this.src.match(/@2x.png$/)) return;
let e = new Image;
e.onload = function() {
this.width && this.height && (o.src = this.src);
}, e.src = this.src.replace(".png", "@2x.png");
}, o.complete && o.onload();
}
};
},
580: function(e, t, o) {
let n = o(829);
e.exports = function() {
let e = null;
function t(t) {
let o = t.clientX + 8;
o + e.offsetWidth > document.documentElement.clientWidth && (o = Math.max(0, t.clientX - 8 - e.offsetWidth)), 
e.style.left = o + "px";
let n = t.clientY + 10;
n + e.offsetHeight > document.documentElement.clientHeight && (n = Math.max(0, t.clientY - 10 - e.offsetHeight)), 
e.style.top = n + "px";
}
n("a,[data-tooltip]", (function(o) {
o.closest && ("A" == o.tagName && o.closest(".toolbar") || o.classList.contains("button") || (e = document.createElement("span"), 
e.className = "link__type", o.getAttribute("data-tooltip") ? (e.innerHTML = o.getAttribute("data-tooltip"), 
e.setAttribute("data-tooltip", "1")) : e.setAttribute("data-url", o.getAttribute("href")), 
document.body.append(e), t(event), document.addEventListener("mousemove", t)));
}), (function() {
e && (document.removeEventListener("mousemove", t), e.remove(), e = null);
}));
};
},
829: function(e) {
let t, o, n = 1 / 0, i = 1 / 0, l = Date.now(), r = {};
document.addEventListener("mousemove", (function(e) {
if (o) return;
if (Math.sqrt(Math.pow(e.pageX - n, 2) + Math.pow(e.pageY - i, 2)) / (Date.now() - l) < .2) {
let n = document.elementFromPoint(e.clientX, e.clientY);
if (!n) return;
if (n !== t) {
for (let e in r) {
let t = n.closest(e);
t && (o = {
elem: t,
out: r[e].out
}, r[e].over(t));
}
t = n;
}
}
n = e.pageX, i = e.pageY, l = Date.now();
})), document.addEventListener("mouseout", (function(e) {
if (!o) return;
let t = e.relatedTarget;
for (;t && (!t.hasAttribute("data-tooltip") || t === o.elem); ) {
if (t === o.elem) return;
t = t.parentElement;
}
let {elem: n, out: i} = o;
o = null, i(n);
})), e.exports = function(e, t, o) {
r[e] = {
over: t,
out: o
};
};
},
225: function(e) {
function t(e) {
let t = document.createElement("div"), o = getComputedStyle(e);
return t.style.width = e.offsetWidth + "px", t.style.marginLeft = o.marginLeft, 
t.style.marginRight = o.marginRight, t.style.position = o.position, t.style.height = e.offsetHeight + "px", 
t.style.marginBottom = o.marginBottom, t.style.marginTop = o.marginTop, t;
}
e.exports = function() {
let e = document.querySelectorAll("[data-sticky]");
for (let o = 0; o < e.length; o++) {
let n = e[o], i = n.dataset.sticky ? JSON.parse(n.dataset.sticky) : {}, l = i.bottomLimit ? document.querySelector(i.bottomLimit) : null, r = i.container ? document.querySelector(i.container) : document.body, s = !i.minWidth || document.documentElement.clientWidth > i.minWidth;
if (n.placeholder) (n.placeholder.getBoundingClientRect().top > 0 || !s) && (n.style.cssText = "", 
n.classList.remove("sticky"), n.placeholder.parentNode.insertBefore(n, n.placeholder), 
n.placeholder.remove(), n.placeholder = null); else if (n.placeholder && l) l.getBoundingClientRect().top <= n.offsetHeight ? ("fixed" == n.style.position && (n.style.top = window.pageYOffset + "px"), 
n.style.position = "absolute") : (n.style.position = "fixed", n.style.top = 0); else if (n.getBoundingClientRect().top < 0 && s) {
if (n.style.cssText) return;
let e, o;
i.saveRight ? o = document.documentElement.clientWidth - n.getBoundingClientRect().right : e = n.getBoundingClientRect().left;
let l = i.noPlaceholder ? document.createElement("div") : t(n), s = n.offsetWidth;
n.after(l), r.appendChild(n), n.classList.add("sticky"), n.style.position = "fixed", 
n.style.top = 0, i.saveRight ? n.style.right = o + "px" : n.style.left = e + "px", 
n.style.zIndex = 101, n.style.background = "white", n.style.margin = 0, n.style.width = s + "px", 
n.placeholder = l;
}
}
};
},
169: function(e, t, o) {
const n = o(650);
e.exports = function(e) {
if ("string" != typeof e) return;
const t = e.toUpperCase();
return Object.prototype.hasOwnProperty.call(n, t) ? n[t] : void 0;
}, e.exports.currencySymbolMap = n;
},
650: function(e) {
e.exports = {
AED: "د.إ",
AFN: "؋",
ALL: "L",
AMD: "֏",
ANG: "ƒ",
AOA: "Kz",
ARS: "$",
AUD: "$",
AWG: "ƒ",
AZN: "₼",
BAM: "KM",
BBD: "$",
BDT: "৳",
BGN: "лв",
BHD: ".د.ب",
BIF: "FBu",
BMD: "$",
BND: "$",
BOB: "$b",
BOV: "BOV",
BRL: "R$",
BSD: "$",
BTC: "₿",
BTN: "Nu.",
BWP: "P",
BYN: "Br",
BYR: "Br",
BZD: "BZ$",
CAD: "$",
CDF: "FC",
CHE: "CHE",
CHF: "CHF",
CHW: "CHW",
CLF: "CLF",
CLP: "$",
CNY: "元",
COP: "$",
COU: "COU",
CRC: "₡",
CUC: "$",
CUP: "₱",
CVE: "$",
CZK: "Kč",
DJF: "Fdj",
DKK: "kr",
DOP: "RD$",
DZD: "دج",
EEK: "kr",
EGP: "£",
ERN: "Nfk",
ETB: "Br",
ETH: "Ξ",
EUR: "€",
FJD: "$",
FKP: "£",
GBP: "£",
GEL: "₾",
GGP: "£",
GHC: "₵",
GHS: "GH₵",
GIP: "£",
GMD: "D",
GNF: "FG",
GTQ: "Q",
GYD: "$",
HKD: "$",
HNL: "L",
HRK: "kn",
HTG: "G",
HUF: "Ft",
IDR: "Rp",
ILS: "₪",
IMP: "£",
INR: "₹",
IQD: "ع.د",
IRR: "﷼",
ISK: "kr",
JEP: "£",
JMD: "J$",
JOD: "JD",
JPY: "¥",
KES: "KSh",
KGS: "лв",
KHR: "៛",
KMF: "CF",
KPW: "₩",
KRW: "₩",
KWD: "KD",
KYD: "$",
KZT: "₸",
LAK: "₭",
LBP: "£",
LKR: "₨",
LRD: "$",
LSL: "M",
LTC: "Ł",
LTL: "Lt",
LVL: "Ls",
LYD: "LD",
MAD: "MAD",
MDL: "lei",
MGA: "Ar",
MKD: "ден",
MMK: "K",
MNT: "₮",
MOP: "MOP$",
MRO: "UM",
MRU: "UM",
MUR: "₨",
MVR: "Rf",
MWK: "MK",
MXN: "$",
MXV: "MXV",
MYR: "RM",
MZN: "MT",
NAD: "$",
NGN: "₦",
NIO: "C$",
NOK: "kr",
NPR: "₨",
NZD: "$",
OMR: "﷼",
PAB: "B/.",
PEN: "S/.",
PGK: "K",
PHP: "₱",
PKR: "₨",
PLN: "zł",
PYG: "Gs",
QAR: "﷼",
RMB: "元",
RON: "lei",
RSD: "Дин.",
RUB: "₽",
RWF: "R₣",
SAR: "﷼",
SBD: "$",
SCR: "₨",
SDG: "ج.س.",
SEK: "kr",
SGD: "S$",
SHP: "£",
SLL: "Le",
SOS: "S",
SRD: "$",
SSP: "£",
STD: "Db",
STN: "Db",
SVC: "$",
SYP: "£",
SZL: "E",
THB: "฿",
TJS: "SM",
TMT: "T",
TND: "د.ت",
TOP: "T$",
TRL: "₤",
TRY: "₺",
TTD: "TT$",
TVD: "$",
TWD: "NT$",
TZS: "TSh",
UAH: "₴",
UGX: "USh",
USD: "$",
UYI: "UYI",
UYU: "$U",
UYW: "UYW",
UZS: "лв",
VEF: "Bs",
VES: "Bs.S",
VND: "₫",
VUV: "VT",
WST: "WS$",
XAF: "FCFA",
XBT: "Ƀ",
XCD: "$",
XOF: "CFA",
XPF: "₣",
XSU: "Sucre",
XUA: "XUA",
YER: "﷼",
ZAR: "R",
ZMW: "ZK",
ZWD: "Z$",
ZWL: "$"
};
}
}, t = {};
function o(n) {
var i = t[n];
if (void 0 !== i) return i.exports;
var l = t[n] = {
exports: {}
};
return e[n](l, l.exports, o), l.exports;
}
let n = o(580), i = o(595), l = o(225), {shopCurrency: r, localCurrency: s} = (o(907).lang, 
o(907));
o(169);
n(), window.devicePixelRatio > 1 && i(), window.addEventListener("scroll", l, {
passive: !0
}), window.addEventListener("resize", l, {
passive: !0
}), l(), footer = {};
}();
//# sourceMappingURL=footer.7f619589a73560c0bc2e.js.map